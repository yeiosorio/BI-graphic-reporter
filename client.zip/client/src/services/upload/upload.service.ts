import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { global } from '../global';

@Injectable({
	providedIn: 'root'
})
export class UploadService {
	URL_API: string;

	//	readonly URL_API = 'http://localhost:8000/api';
	constructor(private http: HttpClient) {
		this.URL_API = global.baseURL;
	}

	sendInfoTable(info: any) {
		return this.http.post(this.URL_API + `/crearTabla`, { infoTable: JSON.stringify(info) });
	}
}
