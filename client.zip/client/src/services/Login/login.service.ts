import { Usuario } from './../../app/models/usuario';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/app/models/user';
import { global } from '../global';
interface respond {
	success: string;
	message: string;
	id: string;
	rol_id: string;
	username: string;
	nombre: string;
	correo: string;
	identificacion: string;
}

@Injectable({
	providedIn: 'root'
})
export class UsuarioService {
	URL_API: string;
	selecUsuario: Usuario;
	Usuarios: Usuario[];
	//readonly URL_API = 'http://localhost:8000/';

	constructor(private http: HttpClient) {
		this.URL_API = global.baseURL;
		this.selecUsuario = new Usuario();
	}

	registrar(Usuario: Usuario) {
		return this.http.post<respond>(this.URL_API + `crearUsuario`, Usuario);
	}

	autenticar(user: User) {
		return this.http.post<respond>(this.URL_API + `auth`, user);
	}
}
