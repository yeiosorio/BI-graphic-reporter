import { RouterModule, Routes } from '@angular/router';
// importing component...
import { UploadComponent } from './upload/upload.component';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './login/login.component';
import { PlanesComponent } from './planes/planes.component';

const app_routes: Routes = [
	{ path: 'login', component: LoginComponent },
	{ path: 'upload', component: UploadComponent },
	{ path: 'graph', component: IndexComponent },
	{ path: 'planes', component: PlanesComponent },
	{ path: '**', pathMatch: 'full', redirectTo: 'login' }
	// path: '**' -> cualquier otra direccion
];

export const app_routing = RouterModule.forRoot(app_routes);
