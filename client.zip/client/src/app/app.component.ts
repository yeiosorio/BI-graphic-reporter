import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { global } from '../services/global';

declare var M: any;

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: [ './app.component.css' ]
})
export class AppComponent {
	language = 'en';
	constructor(private translate: TranslateService) {
		M.AutoInit();
		this.changeLanguaje(this.language);
	}

	changeLanguaje(language) {
		this.language = language;
		// se declara por defecto un idioma
		this.translate.setDefaultLang(language);
		this.translate.use(language);
	}
}
