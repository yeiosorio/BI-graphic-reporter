import { RouterModule, Router } from '@angular/router';
import { UsuarioService } from '../../services/Login/login.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Usuario } from '../models/usuario';
import { User } from '../models/user';

declare var M: any;
@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: [ './login.component.css' ]
})
export class LoginComponent implements OnInit {
	user = {} as User;

	constructor(public usuarioService: UsuarioService, private router: Router) {
		this.usuarioService.selecUsuario.rol_id = 2;
		this.usuarioService.selecUsuario.observacion = '';
	}

	ngOnInit() {
		// inicia los componentes de materialize
		M.AutoInit();
	}
	//funcion que permite limpiar los campos del formulario
	resetForm(form?: NgForm) {
		if (form) {
			form.reset();
			this.usuarioService.selecUsuario = new Usuario();
		}
	}

	// funcion que permite el registro de usuarios
	registrar(form?: NgForm) {
		this.usuarioService.registrar(form.value).subscribe((res) => {
			console.log(res);
			if (res.success) {
				M.toast({ html: 'Bienvenido a GLReports' });
				this.resetForm(form);
				this.router.navigate([ '/planes' ]);
			} else {
				M.toast({ html: 'Ocurrio un problema' });
			}
		});
	}

	// funcion que permite la autenticacion de usuarios
	autenticar(user: User) {
		this.usuarioService.autenticar(user).subscribe((res) => {
			console.log(res);
			if (res.success) {
				let usuario = {
					id: res.id,
					identificacion: res.identificacion,
					nombre: res.nombre,
					rol_id: res.rol_id,
					username: res.username,
					correo: res.correo
				};
				// se guarda los datos del usuario autenticado en el localstorage
				localStorage.setItem('usuario', JSON.stringify(usuario));
				this.router.navigate([ '/planes' ]);
				//this.router.navigate([ '/upload' ]);
			} else {
				M.toast({ html: res.message });
			}
		});
	}
}
