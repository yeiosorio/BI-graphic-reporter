export class Usuario {
	id: number;
	rol_id: number;
	nomb_usuario: string;
	contrasena: string;
	nombre: string;
	apellido: string;
	correo: string;
	identificacion: string;
	observacion: string;
	estado: number = 1;
}
