import { Component, OnInit, ViewChild } from '@angular/core';
import { Papa } from 'ngx-papaparse';
import { UploadService } from '../../services/upload/upload.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';

@Component({
	selector: 'app-upload',
	templateUrl: './upload.component.html',
	styleUrls: [ './upload.component.css' ],
	providers: [ UploadService ]
})
export class UploadComponent implements OnInit {
	header: any;
	datos: any;
	files: any;
	headerSave: any;
	infHead: any;
	// datatable
	//displayedColumns: string[] = [ 'name', 'po' ];
	displayedColumns: string[];
	nameTable: string;
	///////
	constructor(private papa: Papa, private uploadService: UploadService) {}
	dataSource: MatTableDataSource<any>;
	//datatable
	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild(MatSort) sort: MatSort;
	///////
	ngOnInit() {
		//datatable
		// this.dataSource.paginator = this.paginator;
		// this.dataSource.sort = this.sort;
		////
	}

	applyFilter(filterValue: string) {
		this.dataSource.filter = filterValue.trim().toLowerCase();
	}

	fileUploads(event) {
		this.files = event.target.files;
	}

	cargarDatos() {
		if (this.files && this.files.length > 0) {
			const file: File = this.files.item(0);
			console.log(file.name);
			console.log(file.size);
			console.log(file.type);
			const reader: FileReader = new FileReader();
			reader.readAsText(file);
			reader.onload = (e) => {
				this.papa.parse(file, {
					complete: (result) => {
						this.header = result.data[0];
						this.displayedColumns = this.header;
						this.headerSave = Object.assign([], this.header);
						this.datos = result.data;
						this.datos.splice(0, 1);
						this.dataSource = new MatTableDataSource(this.datos);
						this.dataSource.paginator = this.paginator;
						this.dataSource.sort = this.sort;
					}
				});
			};
		}
	}

	seleccion(pos) {
		if (this.headerSave.indexOf(this.header[pos]) >= 0) {
			this.headerSave[pos] = '';
		} else {
			this.headerSave[pos] = this.header[pos];
		}
	}

	guardarTabla() {
		if (this.prepararDatos()) {
			var info = new Array();
			info.push(this.header);
			for (var i = 0; i < this.datos.length; i++) {
				info.push(this.datos[i]);
			}
			console.log(this.nameTable);
			this.uploadService.sendInfoTable(info).subscribe((res) => {});
		}
	}

	prepararDatos() {
		for (let j = 0; j < this.headerSave.length; j++) {
			if (this.headerSave[j] == '') {
				this.headerSave.splice(j, 1);
				this.header.splice(j, 1);
				for (var i = 0; i < this.datos.length; i++) {
					this.datos[i].splice(j, 1);
				}
			}
		}
		return true;
	}
}
